// Replace with your own firebase config!
export const FIREBASE_CONFIG = {
  apiKey: "AIzaSyB4eC3HgMHKEvn0eCQefWcnlbEJfRKIxmE",
  authDomain: "hanareadthru.firebaseapp.com",
  databaseURL: "https://hanareadthru.firebaseio.com",
  projectId: "hanareadthru",
  storageBucket: "hanareadthru.appspot.com",
  messagingSenderId: "665524533654",
  appId: "1:665524533654:web:2ed484f7e880f2226705b7",
  measurementId: "G-XGJLHWYSN4"
};
